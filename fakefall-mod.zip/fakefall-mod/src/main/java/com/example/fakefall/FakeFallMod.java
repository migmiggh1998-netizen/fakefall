package com.example.fakefall;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class FakeFallMod implements ModInitializer {
    public static final String MOD_ID = "fakefall";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // ارتفاعی که وقتی پلیر میس بزنه، انگار از این ارتفاع سقوط کرده (به بلاک)
    public static final float FAKE_FALL_DISTANCE = 100.0f;

    // آخرین تیکی که هر پلیر واقعاً به یه entity حمله کرده (نه میس)
    // با UUID پلیر نگه‌داری می‌شه چون entity خود پلیر بین تیک‌ها عوض نمی‌شه ولی ایمن‌تره
    public static final Map<UUID, Integer> LAST_REAL_ATTACK_TICK = new ConcurrentHashMap<>();

    @Override
    public void onInitialize() {
        LOGGER.info("[FakeFall] mod loaded - swing and miss and see what happens");
    }
}
