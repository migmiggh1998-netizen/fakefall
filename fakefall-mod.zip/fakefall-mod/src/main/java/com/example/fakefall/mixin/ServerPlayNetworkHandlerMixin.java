package com.example.fakefall.mixin;

import com.example.fakefall.FakeFallMod;
import net.minecraft.hit.BlockHitResult;
import net.minecraft.hit.HitResult;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * هر بار که سرور یه HandSwingC2SPacket (سوینگ دست) از کلاینت می‌گیره صدا زده می‌شه.
 * این پکت برای هر کلیک چپ فرستاده می‌شه، چه به یه entity بخوره چه به هوا (میس).
 *
 * منطق: اگه توی همین تیک، یه حمله واقعی به entity هم ثبت نشده بود (از ServerPlayerEntityMixin)
 * و پلیر داشت به سمت یه entity نشونه می‌رفت نه یه بلاک، یعنی میس زده -> فیک فال اعمال می‌شه.
 */
@Mixin(ServerPlayNetworkHandler.class)
public abstract class ServerPlayNetworkHandlerMixin {

    @Inject(method = "onHandSwing", at = @At("TAIL"))
    private void fakefall$onHandSwing(HandSwingC2SPacket packet, CallbackInfo ci) {
        ServerPlayNetworkHandler self = (ServerPlayNetworkHandler) (Object) this;
        ServerPlayerEntity player = self.player;

        if (packet.getHand() != Hand.MAIN_HAND) {
            return; // فقط دست اصلی رو حساب می‌کنیم
        }

        if (!(player.getWorld() instanceof ServerWorld serverWorld)) {
            return;
        }

        int currentTick = serverWorld.getServer().getTicks();
        Integer lastAttackTick = FakeFallMod.LAST_REAL_ATTACK_TICK.get(player.getUuid());

        boolean realAttackHappenedThisTick = lastAttackTick != null && lastAttackTick == currentTick;
        if (realAttackHappenedThisTick) {
            return; // این سوینگ مال یه حمله واقعی بود، میس نیست
        }

        // فقط وقتی میس حساب کن که پلیر داشته سمت یه entity نشونه می‌رفته، نه یه بلاک
        // (که یعنی احتمالا داشته ماین می‌کرده)
        double reach = 4.0;
        HitResult hitResult = player.raycast(reach, 1.0F, false);
        if (hitResult != null && hitResult.getType() == HitResult.Type.BLOCK) {
            return; // احتمالا داشته بلاک می‌شکست، میس حساب نمی‌شه
        }

        fakefall$applyFakeFall(player);
    }

    private void fakefall$applyFakeFall(ServerPlayerEntity player) {
        // دقیقا مثل اینکه واقعا از FAKE_FALL_DISTANCE بلاک سقوط کرده باشه
        player.handleFallDamage(FakeFallMod.FAKE_FALL_DISTANCE, 1.0F, player.getDamageSources().fall());
        // فال دیستنس رو صفر کن که رو سقوط‌های بعدی واقعی تاثیر نذاره
        player.fallDistance = 0.0F;
    }
}
