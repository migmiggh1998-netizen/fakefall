package com.example.fakefall.mixin;

import com.example.fakefall.FakeFallMod;
import net.minecraft.entity.Entity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * هر وقت پلیر واقعاً به یه entity حمله کنه (پکت attack پردازش بشه)،
 * این متد صدا زده می‌شه. اینجا فقط یادداشت می‌کنیم که "تو این تیک، حمله واقعی بوده"
 * تا توی ServerPlayNetworkHandlerMixin بفهمیم سوینگ بعدی میس بوده یا نه.
 */
@Mixin(ServerPlayerEntity.class)
public abstract class ServerPlayerEntityMixin {

    @Inject(method = "attack", at = @At("HEAD"))
    private void fakefall$onAttack(Entity target, CallbackInfo ci) {
        ServerPlayerEntity self = (ServerPlayerEntity) (Object) this;
        if (self.getWorld() instanceof ServerWorld serverWorld) {
            int tick = serverWorld.getServer().getTicks();
            FakeFallMod.LAST_REAL_ATTACK_TICK.put(self.getUuid(), tick);
        }
    }
}
